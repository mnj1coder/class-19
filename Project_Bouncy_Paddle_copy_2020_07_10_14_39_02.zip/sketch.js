var ball,img,paddle;
var round;

function preload() {
  /* preload your images here of the ball and the paddle */
  round = loadImage("ball.png");
}
function setup() {
  createCanvas(400, 400);
   
  var ball = createSprite(350,200,10,10);
  
  ball.addImage ("img",round);
  
  
  ball.velocityY = -2;
  ball.velocityX = 2;
  

}

function draw() {
  background(205,153,0);
  
  
  createEdgeSprites();
  
  /* Allow the ball sprite to bounceOff the left, top and bottom edges only, leaving the right edge of the canvas to be open. */
  
  //ball.bounceOff(topEdge);
  

  /* Allow the ball to bounceoff from the paddle */
  /* Also assign a collision callback function, so that the ball can have a random y velocity, making the game interesting */
 
  /* Prevent the paddle from going out of the edges */ 
  
  
  if(keyDown(UP_ARROW))
  {
     /* what should happen when you press the UP Arrow Key */
  }
  
  if(keyDown(DOWN_ARROW))
  {
    /* what should happen when you press the UP Arrow Key */
  }
  drawSprites();
  
}

function randomVelocity()
{
  /* this function gets called when the ball bounces off the paddle */
  /* assign the ball a random vertical velocity, so it bounces off in random direction */
}

